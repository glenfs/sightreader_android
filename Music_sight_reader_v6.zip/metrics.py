import json

from kivy.core.audio import SoundLoader
from kivy.metrics import dp
from kivy.uix.floatlayout import FloatLayout
from kivymd.app import MDApp
from kivymd.uix.button import MDRoundFlatIconButton
from kivymd.uix.datatables import MDDataTable
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label


class SightReaderStatisticsScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical')
        layout.spacing = 10
        layout.padding = 20

        # Page Heading
        page_heading = Label(
            text='Sight Reader Statistics',
            size_hint=(1, 0.15),
            height=dp(100),
            halign='center',
            valign='middle',
            font_name = "littledays"
        )
        #self.bg_music = SoundLoader.load('sounds/gaudete.mp3')
        layout.add_widget(page_heading)

        # Create MDDataTable
        self.data_tables = MDDataTable(
            size_hint=(1, 0.90),  # Adjust the size_hint to make it take the whole space
            use_pagination=False,  # Turn off pagination
            check=False,
            rows_num=30,
            column_data=[
                ("[font=littledays]Note Name", dp(30)),
                ("[font=littledays]Attempted", dp(35)),
                ("[font=littledays]Correct", dp(40)),
                ("[font=littledays]Accuracy", dp(30))
            ]
        )
        layout.add_widget(self.data_tables)

        # Load and populate data
        self.load_data()
        float_layout = FloatLayout()
        # Create Home button
        home_button = MDRoundFlatIconButton(
            icon="home",
            text='Home', halign="center",font_name = "littledays"
        )

        home_button.pos_hint = {"center_x": 0.9, "center_y": 0.9}
        home_button.bind(on_release=self.go_to_menu)

        float_layout.add_widget(home_button)

        reset_button = MDRoundFlatIconButton(
            icon="home",
            text='Reset', halign="center",font_name = "littledays"
        )
        reset_button.pos_hint = {"x": 0.05, "center_y": 0.9}
        reset_button.bind(on_release=self.reset_metrics)

        float_layout.add_widget(reset_button)

        self.add_widget(layout)
        self.add_widget(float_layout)

    def load_data(self):
        # Clear the existing data
        self.data_tables.row_data = []
        self.data_tables.font_name = "littledays"

        # Generate JSON-like data dynamically
        note_values = [
            '[C2', 'D2', 'E2', 'F2', 'G2', 'A3', 'B3', 'C3', 'D3', 'E3', 'F3', 'G3', 'A4',
            'B4', 'C4', 'D4', 'E4', 'F4', 'G4', 'A5', 'B5', 'C5', 'D5', 'E5', 'F5', 'G5',
            'A6', 'B6', 'C6'
        ]

        data = []

        with open("./score_data.json", "r") as file:
            data = json.load(file)

        # Populate the MDDataTable
        for row in data:
            self.data_tables.row_data.append([row['Note Name'], row['Attempted'], row['Correct'], row['Accuracy']])

    def go_to_menu(self, instance):
        app = MDApp.get_running_app()
        #self.stop_bg_music()
        app.root.get_screen('menu').play_music()
        self.manager.current = 'menu'
        app.change_palette(theme='Dark', prim_palette='Cyan')

    def reset_metrics(self, instance):

        with open("./score_data.json", "r") as file:
            data = json.load(file)

        for entry in data:
            entry["Attempted"] = 0
            entry["Correct"] = 0
            # Recalculate Accuracy
            entry["Accuracy"] = ""

        # Write the updated data back to the JSON file
        with open("./score_data.json", "w") as file:
            json.dump(data, file, indent=0)

        # Clear the existing data
        self.data_tables.row_data = []
        self.load_data()

    def play_bg_music(self):
        self.bg_music.volume = 0.25
        self.bg_music.play()

    def stop_bg_music(self):
        self.bg_music.stop()